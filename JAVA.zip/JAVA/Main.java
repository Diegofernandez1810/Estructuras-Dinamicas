package JAVA;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ListaDoble lista = new ListaDoble();

        int opcion;

        do {

            System.out.println("\nMENU");
            System.out.println("1 Insertar al inicio");
            System.out.println("2 Insertar al final");
            System.out.println("3 Recorrer hacia adelante");
            System.out.println("4 Recorrer hacia atras");
            System.out.println("5 Mostrar tamaño");
            System.out.println("6 Ver si la lista esta vacia");
            System.out.println("7 Buscar por valor");
            System.out.println("8 Borrar elemento");
            System.out.println("0 Salir");

            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    System.out.print("Ingrese valor: ");
                    lista.insertarInicio(sc.nextInt());
                    break;

                case 2:
                    System.out.print("Ingrese valor: ");
                    lista.insertarFinal(sc.nextInt());
                    break;

                case 3:
                    lista.recorrerAdelante();
                    break;

                case 4:
                    lista.recorrerAtras();
                    break;

                case 5:
                    System.out.println("Tamaño: " + lista.tamaño());
                    break;

                case 6:
                    if (lista.estaVacia())
                        System.out.println("Lista vacia");
                    else
                        System.out.println("Lista con elementos");
                    break;

                case 7:
                    System.out.print("Valor a buscar: ");
                    lista.buscarValor(sc.nextInt());
                    break;

                case 8:
                    System.out.print("Valor a borrar: ");
                    lista.borrar(sc.nextInt());
                    break;
            }

        } while (opcion != 0);
    }
}
