package JAVA;

public class ListaDoble {
    Nodo inicio;
    Nodo fin;

    public ListaDoble() {
        inicio = null;
        fin = null;
    }

    public void insertarInicio(int dato) {

        Nodo nuevo = new Nodo(dato);

        if (inicio == null) {
            inicio = fin = nuevo;
        } else {
            nuevo.siguiente = inicio;
            inicio.anterior = nuevo;
            inicio = nuevo;
        }
    }

    public void insertarFinal(int dato) {

        Nodo nuevo = new Nodo(dato);

        if (inicio == null) {
            inicio = fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            nuevo.anterior = fin;
            fin = nuevo;
        }
    }

    public void recorrerAdelante() {

        Nodo temp = inicio;

        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }

        System.out.println();
    }

    public void recorrerAtras() {

        Nodo temp = fin;

        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.anterior;
        }

        System.out.println();
    }

    public int tamaño() {

        int contador = 0;
        Nodo temp = inicio;

        while (temp != null) {
            contador++;
            temp = temp.siguiente;
        }

        return contador;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    public void buscarValor(int valor) {

        Nodo temp = inicio;
        int posicion = 0;

        while (temp != null) {

            if (temp.dato == valor) {
                System.out.println("Elemento encontrado en posicion: " + posicion);
                return;
            }

            posicion++;
            temp = temp.siguiente;
        }

        System.out.println("Elemento no encontrado");
    }

    public void borrar(int valor) {

        Nodo temp = inicio;

        while (temp != null) {

            if (temp.dato == valor) {

                if (temp == inicio) {
                    inicio = inicio.siguiente;
                    if (inicio != null)
                        inicio.anterior = null;
                }

                else if (temp == fin) {
                    fin = fin.anterior;
                    fin.siguiente = null;
                }

                else {
                    temp.anterior.siguiente = temp.siguiente;
                    temp.siguiente.anterior = temp.anterior;
                }

                System.out.println("Elemento eliminado");
                return;
            }

            temp = temp.siguiente;
        }

        System.out.println("Elemento no encontrado");
    }
}
